package com.cg.project.exception;

public class MobileNumberException extends Exception {
	
	
	public MobileNumberException () {
	super("Invalid Mobile Number!!!\n Please enter a valid 10 digit Mobile Number");
	}
}
