package com.cg.project.ui;

import java.util.Scanner;

import com.cg.project.dto.Customer;
import com.cg.project.exception.MobileNumberException;
import com.cg.project.exception.NameException;
import com.cg.project.service.AccountServiceImpl;

public class Main {
	public static void main(String args[]) throws NameException,MobileNumberException{
		
		AccountServiceImpl service = new AccountServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		
		String name;
		String mobileNo;
		int age;
		double amount;
		int ch = 0;
		do{
			System.out.println("1.Create New Account\n2.Deposit\n3.Withdraw"
					+ "\n4.Show Balance\n5.Fund Transfer\n6.Exit Application");
			
			System.out.println("\nEnter your choice (1-6): ");
			ch = sc.nextInt();
			
		
			switch(ch){
				case 1 :                               //creating account
						
						System.out.println("Enter customer's name : ");
						name = sc.next();
						 if(!service.validateName(name)){
			                    throw new NameException();
			                }
						
						System.out.println("Enter customer's mobile number : ");
						mobileNo = sc.next();
						 if(!service.validateMobileNumber(mobileNo)){
			                    throw new MobileNumberException();
			                }
						
						
						System.out.println("Enter customer's age : ");
						age = sc.nextInt();
						
						System.out.println("Enter initial amount : ");
						amount = sc.nextDouble();
						
						Customer customer = new Customer();
						
						customer.setName(name);
						customer.setMobileNo(mobileNo);
						customer.setAge(age);
						customer.setInitialBalance(amount);
						
						service.createAccount(customer);						
					
					break;
					
				case 2 :                                //deposit
							
						System.out.println("Enter your mobile number : ");
						mobileNo = sc.next();
						if(!service.validateMobileNumber(mobileNo)){
							throw new MobileNumberException();
						}
						
						System.out.println("Enter the amount you want to deposit");
						amount = sc.nextDouble();
						
						service.deposit(mobileNo, amount);						
					
					break;
					
				case 3 :                                  //withdraw
						System.out.println("Enter your mobile number : ");
						mobileNo = sc.next();
						
						System.out.println("Enter the amount you want to withdraw : ");
						amount = sc.nextDouble();
						
						service.withdraw(mobileNo, amount);
						
					break;
				
				case 4 :                                  //check balance
						System.out.println("Enter the moible number to check balance:");
						mobileNo = sc.next();
						if(!service.validateMobileNumber(mobileNo)){
							throw new MobileNumberException();
						}

						System.out.println("Current Amount "+service.checkBalance(mobileNo));
						System.out.println("..............................................\n\n");
					
					break;
					
				case 5 :                                 //fund transfer
					
						System.out.println("Enter your mobile number : ");
						String mobileNoSender = sc.next();
						if(!service.validateMobileNumber(mobileNoSender)){
							throw new MobileNumberException();
						}
					
						System.out.println("Enter receiver's mobile number : ");
						String mobileNoReciever = sc.next();
						if(!service.validateMobileNumber(mobileNoReciever)){
							throw new MobileNumberException();
						}
					
						System.out.println("Enter the amount you want to transfer : ");
						amount = sc.nextDouble();
					
					
						service.fundTransfer(mobileNoSender, mobileNoReciever, amount);	
					break;
					
				case 6 :
						System.out.println("you have exited!\n\n");
					break;
					
				default : System.out.println("Invalid input!\nPlease select from 1 to 6\n\n");
			}
			
		}while(ch != 6);
		
	}
}
