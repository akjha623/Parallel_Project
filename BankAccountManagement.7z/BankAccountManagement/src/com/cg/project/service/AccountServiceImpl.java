package com.cg.project.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.project.dao.AccountDAO;
import com.cg.project.dao.AccountDAOImpl;
import com.cg.project.dto.Customer;

public class AccountServiceImpl implements AccountService{

	AccountDAO dao  = new AccountDAOImpl();
	
	
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		dao.createAccount(customer);		
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		dao.deposit(mobileNo, amount);
		
	}

	@Override
	public void withdraw(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		dao.withdraw(mobileNo, amount);
		
	}

	@Override
	public double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		return dao.checkBalance(mobileNo);
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		dao.fundTransfer(sender, reciever, amount);
		
	}

	@Override
	public boolean validateName(String name) {
		
		Pattern p= Pattern.compile("[A-Z]{1}[a-z]{2,20}");
		Matcher mt= p.matcher(name);
		boolean b= mt.matches();
		
		return b;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateMobileNumber(String mobileNo) {
		// TODO Auto-generated method stub
		 Pattern p = Pattern.compile("[1-9]{1}[0-9]{9}");
	        Matcher mt = p.matcher(mobileNo);
	        boolean b= mt.matches();
	        
	        return b;
	}

	@Override
	public boolean validateAll(Customer ct) {
		// TODO Auto-generated method stub
		boolean b=false;
		
		if(validateName(ct.getName()) == true && validateMobileNumber(ct.getMobileNo()) == true)
			b = true;
		
		return b;
	}

}
